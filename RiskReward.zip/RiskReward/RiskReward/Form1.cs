﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RiskReward
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lblResult.ForeColor = Color.LightGreen;
            lblResult.Text = (numericUpDown1.Value / numericUpDown2.Value).ToString("f1");
            if (float.Parse(lblResult.Text) >= 0.7) lblResult.Text += "% << Result";
            else { lblResult.Text = "Not Good Enter This Trade"; lblResult.ForeColor = Color.Red; }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            float temp = (float)(float.Parse(txtEquity.Text) * float.Parse(txtSL.Text)) / 100;
            float tempRisk = float.Parse(numFloatRisk.Value.ToString());
            temp = (temp * tempRisk) / 100;
            for (int i = 0; i < numFloatRisk.Value; i++)
            {
                temp = temp / 2;
            }
            txtRiskResult.Text = temp.ToString("f2");
        }
    }
}
